<?php
function selectSpesificTask($taskNumber){
    include "database.php";
    $dataFinal = array();
    $sqlCheckData = "SELECT * FROM re_events WHERE task_number = $taskNumber";
    $executeCheckData = mysqli_query($conn, $sqlCheckData);

    if ($executeCheckData && mysqli_num_rows($executeCheckData) > 0) {
        $data = mysqli_fetch_assoc($executeCheckData);
        $dataFinal['task_number'] = $data['task_number'];
        $dataFinal['event_details'] = $data['event_details'];
        $dataFinal['plan_completed_date'] = $data['plan_completed_date'];
    }

    return $dataFinal;
}

function updateEvent($taskNumber, $eventDetails, $planCompletedDate){
    include "database.php";

    $sqlUpdate = "UPDATE re_events SET event_details = '$eventDetails', plan_completed_date = '$planCompletedDate' 
    WHERE task_number = $taskNumber";
    $executeUpdateData = mysqli_query($conn, $sqlUpdate);

    $dataFinal = "Success";
    return $dataFinal;
}

function selectSqlDataFileDrive(){
    include "database.php";
    $sqlSelect = "SELECT * FROM re_file_list";
    $executeSelectData = mysqli_query($conn, $sqlSelect);
    $data = mysqli_fetch_all($executeSelectData, MYSQLI_ASSOC);

    return $data;
}

function deleteSqlDataFileDrive($fileIdDrive){
    include "database.php";
    $sqlDelete = "DELETE FROM re_file_list WHERE file_id_drive = '$fileIdDrive'";
    $executeDeleteRow = mysqli_query($conn, $sqlDelete);

    $data = "Success";
    return $data;
}

function insertDataFileDrive($fileName, $fileIdDrive, $fileDirectory){
    include "database.php";
    $sqlInsert = "INSERT INTO re_file_list (file_name, file_id_drive, file_directory)
    VALUES ('$fileName', '$fileIdDrive', '$fileDirectory')";
    $executeInsertData = mysqli_query($conn, $sqlInsert);

    $dataFinal = "Success";
    return $dataFinal;
}

function insertFileToDrive( $file_path, $file_name, $parent_file_id = null ){
    $service = new Google_Service_Drive( $GLOBALS['client'] );
    $file = new Google_Service_Drive_DriveFile();
    $file->setName( $file_name );

    if( !empty( $parent_file_id ) ){
        $file->setParents( [ $parent_file_id ] );        
    }

    $result = $service->files->create(
        $file,
        array(
            'data' => file_get_contents($file_path),
            'mimeType' => 'application/octet-stream',
        )
    );

    $fileId = $result->getId();
    return $fileId;
}

function deleteDataFileDrive($fileIdDrive){
    // Create a new Google Drive client.
    $service = new Google_Service_Drive($GLOBALS['client']);

    // Delete the file.
    try {
        $service->files->delete($fileIdDrive);
        $dataFinal = "Success";
        return $dataFinal;
    } catch (Exception $e) {
        echo "An error occurred: " . $e->getMessage();
    }
}

function deleteDataFileServer($linkToPath){
    $filePath = $linkToPath;

    if (unlink($filePath)) {
        $dataFinal = "Success";
        return $dataFinal;
    } else {
        $dataFinal = "Failed";
        return $dataFinal;
    }
}


?>